# Hannah Yawt — Matrix Cybersecurity Portfolio

A responsive, multi-page student portfolio with a Matrix-inspired green-on-black theme and a simulated command terminal.

## Files

- `index.html` — homepage and interactive terminal
- `projects.html` — project cards to customize
- `about.html` — biography and profile image
- `contact.html` — public contact options
- `style.css` — shared theme, Flexbox, CSS Grid, and media queries
- `script.js` — mobile navigation and safe simulated terminal behavior
- `profile.pic.JPEG` — optional profile image; add your own image using this exact filename if you want it to appear

## Put this project in a new GitHub repository

1. Download and unzip this project.
2. In GitHub, create a new repository (for example, `matrix-cybersecurity-portfolio`).
3. Upload the files from inside the unzipped folder to the **root** of the repository. Do not upload only the ZIP file.
4. Commit the files.
5. To publish it with GitHub Pages, open the repository's **Settings → Pages**.
6. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
7. Wait for the Pages deployment to finish. GitHub will show the published site URL in Settings → Pages.

## Before publishing

- Replace `YOUR-EMAIL@example.com` in `contact.html` with an email address you are comfortable sharing publicly, or remove the email button.
- Add your profile image as `profile.pic.JPEG`, or change the filename in `about.html` to match your image.
- Replace the sample project cards in `projects.html` with real coursework and projects as you complete them.
- Check every page on a phone-sized screen and a desktop screen.

## Responsive-design concepts included

- Flexbox: header/navigation, button rows, terminal controls, and footer.
- CSS Grid: feature cards, project cards, About layout, and Contact layout.
- Media queries: layout changes at 760px and 520px.
- Accessibility: semantic landmarks, labels, keyboard focus styles, and reduced-motion support.

## Important note

The terminal is a front-end demonstration only. It recognizes a small set of portfolio commands and does not run operating-system or cybersecurity commands.
